import React,{useState} from "react";
import '../registrationForm/registerform.css'
import axios from "axios"

const Form =()=>{
 
    const[user,setUser]=useState({
        firstname:"",
        username:"",
        email:"",
        password:"",
        confirmpassword:"",
        phone:"",
        gender:""

    })

     const handleChange= e =>{
        const {name, value}=e.target
        setUser({
            ...user,
            [name]:value
        })
     }
     const register=()=>{
        const{firstname, username,email,phone,password,confirmpassword,gender}=user
        axios.post("http://localhost:4000/app/signup",user)
        
     }


    return(
        
        <div class="container1">
        <div class="title">Registration Form</div>
        <div class="content">
          <form action="/student" method="post"> 
            <div class="user-details">
              <div class="input-box">
                <span class="details">Full Name</span>
                <input type="text" placeholder="Enter your name" name="firstname" value={user.firstname} onChange={handleChange}/>
              </div>
              <div class="input-box">
                <span class="details">Username</span>
                <input type="text" placeholder="Enter your username" name="username" value={user.username} onChange={handleChange}/>
              </div>
              <div class="input-box">
                <span class="details">Email</span>
                <input type="text" placeholder="Enter your email" name="email" value={user.email} onChange={handleChange} />
              </div>
              <div class="input-box">
                <span class="details">Phone Number</span>
                <input type="text" minlength="10" maxlength="10" name="phone" placeholder="Enter your number" value={user.phone} onChange={handleChange} />
              </div>
              <div class="input-box">
                <span class="details">Password</span>
                <input type="text" placeholder="Enter your password" name="password" value={user.password} onChange={handleChange} />
              </div>
              <div class="input-box">
                <span class="details">Confirm Password</span>
                <input type="text" placeholder="Confirm your password" name="confirmpassword" value={user.confirmpassword} onChange={handleChange}/>
              </div>
            </div>
            <div class="gender-details">
              <input type="radio" name="gender" id="dot-1" value={user.gender} onChange={handleChange}/>
              <input type="radio" name="gender" id="dot-2"  value={user.gender} onChange={handleChange}/>
              <input type="radio" name="gender" id="dot-3"  value={user.gender} onChange={handleChange}/>
              <span class="gender-title">Gender</span>
              <div class="category">
                <label for="dot-1">
                <span class="dot one"></span>
                <span class="gender">Male</span>
              </label>
              <label for="dot-2">
                <span class="dot two"></span>
                <span class="gender">Female</span>
              </label>
              <label for="dot-3">
                <span class="dot three"></span>
                <span class="gender">Prefer not to say</span>
                </label>
              </div>
            </div>
            <div class="button">
              <input type="submit" value="Register" onClick={register}/>
            </div>
          </form>
        </div>
      </div>

    )
}
export default Form